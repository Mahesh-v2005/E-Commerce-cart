const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
const PORT = 5000;

mongoose.connect('mongodb://127.0.0.1:27017/ecommerce', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

app.use(cors());
app.use(express.json());

let products = [
  { id: 1, name: 'Pizza', price: 10 },
  { id: 2, name: 'Burger', price: 8 },
  { id: 3, name: 'Pasta', price: 12 },
  { id: 4, name: 'Fries', price: 5 },
  { id: 5, name: 'Ice Cream', price: 6 }
];

app.get('/api/products', (req, res) => {
  res.json(products);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});